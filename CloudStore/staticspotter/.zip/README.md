#### CloudStore Example - StaticSpotter project
-------

##### About

##### Project contents 

##### Run

##### Possible configurations 

##### Results





