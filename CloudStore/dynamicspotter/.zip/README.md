#### CloudStore Example - DynamicSpotter project
-------

##### About

##### Project contents 

##### Run

##### Possible configurations 

##### Results





